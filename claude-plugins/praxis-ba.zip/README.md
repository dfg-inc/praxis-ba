# Praxis BA

Claude UI / Cowork plugin for Praxis 0.1.0-alpha.42.

Praxis BA requires:
- the Praxis Runtime Desktop Extension (`claude-extensions/praxis-runtime.mcpb`) installed and enabled
- Jira fields completed in Praxis Runtime settings (token is sensitive; never paste it into chat)
- a supported Claude workspace / Cowork execution surface with project access
- access to the product repository

Do not paste Jira tokens into chat. Do not run `praxis`, `make`, `launchctl`, or edit config files for normal use.

Primary workflow: invoke a role Skill and speak naturally. Tools come from the shared Praxis Runtime MCP, not a per-plugin server.

Claude Chat may show Skills, but local edit/test flow needs workspace/runtime capabilities. If the repository or local runtime is unavailable the tools return `REPOSITORY_UNAVAILABLE` or `LOCAL_RUNTIME_UNAVAILABLE` instead of pretending work ran.
